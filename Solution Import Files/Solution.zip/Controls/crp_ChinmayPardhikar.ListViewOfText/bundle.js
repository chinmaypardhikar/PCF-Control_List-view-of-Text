/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ListViewOfText/index.ts":
/*!*********************************!*\
  !*** ./ListViewOfText/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ListViewOfText = void 0;\nvar ListViewOfText = /** @class */function () {\n  function ListViewOfText() {}\n  ListViewOfText.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.context = context;\n    this.notifyOutputChanged = notifyOutputChanged;\n    // Add control initialization code\n    this.container = container;\n    this.container.setAttribute(\"class\", \"Container\");\n    //inputContainer\n    this.inputContainer = document.createElement(\"div\");\n    this.inputContainer.setAttribute(\"class\", \"Input-Container\");\n    //Form\n    this.form = document.createElement(\"form\");\n    this.form.setAttribute(\"id\", \"form\");\n    //Input \n    this.input = document.createElement(\"input\");\n    this.input.setAttribute(\"type\", \"text\");\n    this.input.setAttribute(\"value\", \"\");\n    this.input.setAttribute(\"class\", \"input-field\");\n    this.input.setAttribute(\"id\", \"InputValue\");\n    this.input.setAttribute(\"placeholder\", context.parameters.placeholderName.raw || \"\");\n    //Button\n    this.button = document.createElement(\"button\");\n    this.button.setAttribute(\"type\", \"button\");\n    this.button.setAttribute(\"id\", \"addButton\");\n    this.button.textContent = context.parameters.ButtonName.raw || \"Add\";\n    this.button.style.background = context.parameters.ButtonColor.raw || \"#6471c1\";\n    //Display List\n    this.displayList = document.createElement(\"div\");\n    this.displayList.setAttribute(\"class\", \"Display-list\");\n    this.displayList.setAttribute(\"id\", \"Display-list\");\n    this.displayList.style.maxHeight = context.parameters.VerticalScrollBar.raw || \"none\";\n    //Append tags\n    this.form.appendChild(this.input);\n    this.form.appendChild(this.button);\n    this.inputContainer.appendChild(this.form);\n    this.container.appendChild(this.inputContainer);\n    this.container.appendChild(this.displayList);\n    //Eventlistner\n    this.button.addEventListener(\"click\", this.addDataToList.bind(this));\n    this.input.addEventListener(\"keypress\", function (event) {\n      if (event.key === \"Enter\") {\n        event.preventDefault();\n        document.getElementById(\"addButton\").click();\n      }\n    });\n    this.D365FieldValue = context.parameters.D365Field.raw || \"\";\n    if (!(this.D365FieldValue == \"\" || this.D365FieldValue == null || this.D365FieldValue.trim() == null)) {\n      this.onLoadList();\n    }\n  };\n  ListViewOfText.prototype.updateView = function (context) {};\n  ListViewOfText.prototype.getOutputs = function () {\n    var _a, _b;\n    var display_List = document.getElementById(\"Display-list\");\n    var listCollection = display_List === null || display_List === void 0 ? void 0 : display_List.getElementsByClassName('list-value');\n    var outputValueForD365 = \"\";\n    if (listCollection != undefined) {\n      if (listCollection.length > 0) {\n        outputValueForD365 = ((_a = listCollection[0].getAttribute(\"name\")) === null || _a === void 0 ? void 0 : _a.trim()) || \"\";\n      }\n      for (var i = 1; i < listCollection.length; i++) {\n        outputValueForD365 = outputValueForD365 + (this.context.parameters.TextSeparator.raw || \"ǂ\") + ((_b = listCollection[i].getAttribute(\"name\")) === null || _b === void 0 ? void 0 : _b.trim());\n      }\n    }\n    return {\n      D365Field: outputValueForD365\n    };\n  };\n  ListViewOfText.prototype.destroy = function () {};\n  ListViewOfText.prototype.addDataToList = function () {\n    var inputValue = document.getElementById(\"InputValue\").value;\n    if (inputValue == null || inputValue.trim() == \"\") {\n      document.getElementById(\"InputValue\").value = '';\n      return;\n    }\n    if (!(this.context.parameters.D365Field.raw == null || this.context.parameters.D365Field.raw.trim() == \"\")) {\n      var D365FieldArray = this.context.parameters.D365Field.raw.toLowerCase().split(this.context.parameters.TextSeparator.raw || \"ǂ\");\n      if (D365FieldArray.includes(inputValue.toLowerCase())) {\n        document.getElementById(\"InputValue\").value = '';\n        return;\n      }\n    }\n    this.addItem(inputValue);\n    this.notifyOutputChanged();\n    document.getElementById(\"InputValue\").value = '';\n  };\n  ListViewOfText.prototype.onLoadList = function () {\n    var _this = this;\n    var inputValueArray = this.D365FieldValue.split(this.context.parameters.TextSeparator.raw || \"ǂ\");\n    inputValueArray.forEach(function (inputValue) {\n      _this.addItem(inputValue);\n    });\n    document.getElementById(\"InputValue\").value = '';\n  };\n  ListViewOfText.prototype.addItem = function (inputValue) {\n    this.list = document.createElement(\"div\");\n    this.list.setAttribute(\"class\", \"list\");\n    this.listItem = document.createElement(\"p\");\n    this.listItem.setAttribute(\"name\", inputValue);\n    this.listItem.setAttribute(\"class\", \"list-value\");\n    this.listItem.innerHTML = inputValue;\n    this.list.appendChild(this.listItem);\n    this.image = document.createElement(\"img\");\n    this.image.setAttribute(\"class\", \"cross\");\n    this.image.setAttribute(\"src\", this.context.parameters.DeleteImage.raw || \"https://content.powerapps.com/resource/uci-infra/resources/images/Delete.2713f7a803a36d57dcc050874401427f.svg\");\n    this.image.setAttribute(\"alt\", \"delete\");\n    this.image.setAttribute(\"width\", \"20\");\n    this.image.setAttribute(\"height\", \"20\");\n    this.image.addEventListener(\"click\", this.removeData.bind(this.image, this.notifyOutputChanged));\n    this.list.appendChild(this.image);\n    this.displayList.appendChild(this.list);\n  };\n  ListViewOfText.prototype.removeData = function (notifyOutputChanged) {\n    var _a;\n    (_a = this.parentElement) === null || _a === void 0 ? void 0 : _a.remove();\n    notifyOutputChanged();\n  };\n  return ListViewOfText;\n}();\nexports.ListViewOfText = ListViewOfText;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ListViewOfText/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ListViewOfText/index.ts"](0, __webpack_exports__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ChinmayPardhikar.ListViewOfText', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ListViewOfText);
} else {
	var ChinmayPardhikar = ChinmayPardhikar || {};
	ChinmayPardhikar.ListViewOfText = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ListViewOfText;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}